package com.example.win7.kalories;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by win7 on 2016-07-14.
 */
public class Pcd {
    int pixel,A;
    public Bitmap toGrayscale(Bitmap bitmap){
        Bitmap bmOut=Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        int A, R, G, B;
        int pixel;
        int width=bitmap.getWidth();
        int height=bitmap.getHeight();
        for (int x=0; x<width; ++x){
            for (int y=0; y<height; ++y){
                pixel=bitmap.getPixel(x, y);
                A= Color.alpha(pixel);
                R=Color.red(pixel);
                G=Color.green(pixel);
                B=Color.blue(pixel);
                R=G=B=(int)(R+G+B)/3;
                bmOut.setPixel(x,y, Color.argb(A, R, G, B));
            }
        }
        return bmOut;
    }
    public Bitmap toBinner(Bitmap bitmap){
        bitmap=toGrayscale(bitmap);
        Bitmap bmOut=Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());

        int  R, G, B, CenterValue;

        int width=bitmap.getWidth();
        int height=bitmap.getHeight();
        for (int x=0; x<width; ++x){
            for (int y=0; y<height; ++y){
                pixel=bitmap.getPixel(x, y);
                A= Color.alpha(pixel);
                R=Color.red(pixel);
                G=Color.green(pixel);
                B=Color.blue(pixel);
                CenterValue=(int)(R+G+B)/3;
                if(CenterValue >= 128){
                    R=G=B=(int)255;
                }else{
                    R=G=B=(int)0;
                }
                bmOut.setPixel(x,y, Color.argb(A, R, G, B));
            }
        }
        return bmOut;
    }
    public Bitmap createContrast(Bitmap src, double value) {
        src=toGrayscale(src);
// image size
        int width = src.getWidth();
        int height = src.getHeight();
// create output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, src.getConfig());
// color information
        int A, R, G, B;
        int pixel;
// get contrast value
        double contrast = Math.pow((100 + value) / 100, 2);

// scan through all pixels
        for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
                // get pixel color
                pixel = src.getPixel(x, y);
                A = Color.alpha(pixel);
                // apply filter contrast for every channel R, G, B
                R = Color.red(pixel);
                R = (int)(((((R / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                if(R < 0) { R = 0; }
                else if(R > 255) { R = 255; }

                G = Color.red(pixel);
                G = (int)(((((G / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                if(G < 0) { G = 0; }
                else if(G > 255) { G = 255; }

                B = Color.red(pixel);
                B = (int)(((((B / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                if(B < 0) { B = 0; }
                else if(B > 255) { B = 255; }

                // set new pixel color to output bitmap
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        return bmOut;
    }
    public Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth)
    {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // create a matrix for the manipulation
        Matrix matrix = new Matrix();
        // resize the bit map
        matrix.postScale(scaleWidth, scaleHeight);
        // recreate the new Bitmap
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);
        return resizedBitmap;
    }

    public Bitmap scaleCenterCrop(Bitmap source, int newHeight, int newWidth) {

        int sourceWidth = source.getWidth();
        int sourceHeight = source.getHeight();

        // Compute the scaling factors to fit the new height and width, respectively.
        // To cover the final image, the final scaling will be the bigger
        // of these two.
        float xScale = (float) newWidth / sourceWidth;
        float yScale = (float) newHeight / sourceHeight;
        float scale = Math.max(xScale, yScale);

        // Now get the size of the source bitmap when scaled
        float scaledWidth = scale * sourceWidth;
        float scaledHeight = scale * sourceHeight;

        // Let's find out the upper left coordinates if the scaled bitmap
        // should be centered in the new size give by the parameters
        float left = (newWidth - scaledWidth) / 2;
        float top = (newHeight - scaledHeight) / 2;

        // The target rectangle for the new, scaled version of the source bitmap will now
        // be
        RectF targetRect = new RectF(left, top, left + scaledWidth, top + scaledHeight);

//      RectF targetRect = new RectF(0, 0, newWidth, newHeight/2);
        // Finally, we create a new bitmap of the specified size and draw our new,
        // scaled bitmap onto it.
        Bitmap dest = Bitmap.createBitmap(newWidth, newHeight, source.getConfig());
        Canvas canvas = new Canvas(dest);
        canvas.drawBitmap(source, null, targetRect, null);

        return dest;
    }
    public String toNumber(Bitmap bmim){
        //bmim=toBinner(bmim);
        String converted_txt="";
        String ul;
        byte[][] pixels= new byte[bmim.getWidth()][];
        for (int x = 0; x < bmim.getWidth(); x++) {
            pixels[x] = new byte[bmim.getHeight()];

            for (int y = 0; y < bmim.getHeight(); y++) {
                pixels[x][y] = (byte) (bmim.getPixel(x, y) ==  0xffffffff ? 0 : 1);
                if (x==2||x==9||x==16||x==23||x==30||x==37||x==44||x==49||x==56||x==63||x==70||x==77||x==84||x==91){ ul=","; }else{ul="";}
                converted_txt=converted_txt+pixels[x][y]+ul;
            }
        }

        return converted_txt;
    }
    public String iniSial(String[] pecah){
        String a="";
        String b="";
        String c="";
        String d="";
        String e="";
        String f="";
        String g="";
        String h="";
        String i="";
        String j="";
        String k="";
        String l="";
        String t="";
        String has="";

        if(pecah[1].equals("0011001")||pecah[1].equals("1100110")||pecah[1].equals("0110011")){
            a = "1";
        }else
        if(pecah[1].equals("0010011")||pecah[1].equals("1101100")||pecah[1].equals("0011001")){
            a="2";
        }else
        if(pecah[1].equals("0111101")||pecah[1].equals("1000010")||pecah[1].equals("0100001")){
            a="3";
        }else
        if(pecah[1].equals("0100011")||pecah[1].equals("1011100")||pecah[1].equals("0011101")){
            a="4";
        }else
        if(pecah[1].equals("0110001")||pecah[1].equals("1001110")||pecah[1].equals("0111001")){
            a="5";
        }else
        if(pecah[1].equals("0101111")||pecah[1].equals("1010000")||pecah[1].equals("0000101")){
            a="6";
        }else
        if(pecah[1].equals("0111011")||pecah[1].equals("1000100")||pecah[1].equals("0010001")){
            a="7";
        }else
        if(pecah[1].equals("0110111")||pecah[1].equals("1001000")||pecah[1].equals("0001001")){
            a="8";
        }else
        if(pecah[1].equals("0001011")||pecah[1].equals("1110100")||pecah[1].equals("0010111")){
            a="9";
        }else
        if(pecah[1].equals("0001101")||pecah[1].equals("1110010")||pecah[1].equals("0100111")){
            a="0";
        }else{
            a="0";
        }
        if(pecah[2].equals("0011001")||pecah[2].equals("1100110")||pecah[2].equals("0110011")){
            b = "1";
        }else
        if(pecah[2].equals("0010011")||pecah[2].equals("1101100")||pecah[2].equals("0011001")){
            b="2";
        }else
        if(pecah[2].equals("0111101")||pecah[2].equals("1000010")||pecah[2].equals("0100001")){
            b="3";
        }else
        if(pecah[2].equals("0100011")||pecah[2].equals("1011100")||pecah[2].equals("0011101")){
            b="4";
        }else
        if(pecah[2].equals("0110001")||pecah[2].equals("1001110")||pecah[2].equals("0111001")){
            b="5";
        }else
        if(pecah[2].equals("0101111")||pecah[2].equals("1010000")||pecah[2].equals("0000101")){
            b="6";
        }else
        if(pecah[2].equals("0111011")||pecah[2].equals("1000100")||pecah[2].equals("0010001")){
            b="7";
        }else
        if(pecah[2].equals("0110111")||pecah[2].equals("1001000")||pecah[2].equals("0001001")){
            b="8";
        }else
        if(pecah[2].equals("0001011")||pecah[2].equals("1110100")||pecah[2].equals("0010111")){
            b="9";
        }else
        if(pecah[2].equals("0001101")||pecah[2].equals("1110010")||pecah[2].equals("0100111")){
            b="0";
        }else{
            b="0";
        }

        if(pecah[3].equals("0011001")||pecah[3].equals("1100110")||pecah[3].equals("0110011")){
            c = "1";
        }else
        if(pecah[3].equals("0010011")||pecah[3].equals("1101100")||pecah[3].equals("0011001")){
            c="2";
        }else
        if(pecah[3].equals("0111101")||pecah[3].equals("1000010")||pecah[3].equals("0100001")){
            c="3";
        }else
        if(pecah[3].equals("0100011")||pecah[3].equals("1011100")||pecah[3].equals("0011101")){
            c="4";
        }else
        if(pecah[3].equals("0110001")||pecah[3].equals("1001110")||pecah[3].equals("0111001")){
            c="5";
        }else
        if(pecah[3].equals("0101111")||pecah[3].equals("1010000")||pecah[3].equals("0000101")){
            c="6";
        }else
        if(pecah[3].equals("0111011")||pecah[3].equals("1000100")||pecah[3].equals("0010001")){
            c="7";
        }else
        if(pecah[3].equals("0110111")||pecah[3].equals("1001000")||pecah[3].equals("0001001")){
            c="8";
        }else
        if(pecah[3].equals("0001011")||pecah[3].equals("1110100")||pecah[3].equals("0010111")){
            c="9";
        }else
        if(pecah[3].equals("0001101")||pecah[3].equals("1110010")||pecah[3].equals("0100111")){
            c="0";
        }else{
            c="0";
        }


        if(pecah[4].equals("0011001")||pecah[4].equals("1100110")||pecah[4].equals("0110011")){
            d = "1";
        }else
        if(pecah[4].equals("0010011")||pecah[4].equals("1101100")||pecah[4].equals("0011001")){
            d="2";
        }else
        if(pecah[4].equals("0111101")||pecah[4].equals("1000010")||pecah[4].equals("0100001")){
            d="3";
        }else
        if(pecah[4].equals("0100011")||pecah[4].equals("1011100")||pecah[4].equals("0011101")){
            d="4";
        }else
        if(pecah[4].equals("0110001")||pecah[4].equals("1001110")||pecah[4].equals("0111001")){
            d="5";
        }else
        if(pecah[4].equals("0101111")||pecah[4].equals("1010000")||pecah[4].equals("0000101")){
            d="6";
        }else
        if(pecah[4].equals("0111011")||pecah[4].equals("1000100")||pecah[4].equals("0010001")){
            d="7";
        }else
        if(pecah[4].equals("0110111")||pecah[4].equals("1001000")||pecah[4].equals("0001001")){
            d="8";
        }else
        if(pecah[4].equals("0001011")||pecah[4].equals("1110100")||pecah[4].equals("0010111")){
            d="9";
        }else
        if(pecah[4].equals("0001101")||pecah[1].equals("1110010")||pecah[4].equals("0100111")){
            d="0";
        }else{
            d="0";
        }

        if(pecah[5].equals("0011001")||pecah[5].equals("1100110")||pecah[5].equals("0110011")){
            e = "1";
        }else
        if(pecah[5].equals("0010011")||pecah[5].equals("1101100")||pecah[5].equals("0011001")){
            e="2";
        }else
        if(pecah[5].equals("0111101")||pecah[5].equals("1000010")||pecah[5].equals("0100001")){
            e="3";
        }else
        if(pecah[5].equals("0100011")||pecah[5].equals("1011100")||pecah[5].equals("0011101")){
            e="4";
        }else
        if(pecah[5].equals("0110001")||pecah[5].equals("1001110")||pecah[5].equals("0111001")){
            e="5";
        }else
        if(pecah[5].equals("0101111")||pecah[5].equals("1010000")||pecah[5].equals("0000101")){
            e="6";
        }else
        if(pecah[5].equals("0111011")||pecah[5].equals("1000100")||pecah[5].equals("0010001")){
            e="7";
        }else
        if(pecah[5].equals("0110111")||pecah[5].equals("1001000")||pecah[5].equals("0001001")){
            e="8";
        }else
        if(pecah[5].equals("0001011")||pecah[5].equals("1110100")||pecah[5].equals("0010111")){
            e="9";
        }else
        if(pecah[5].equals("0001101")||pecah[5].equals("1110010")||pecah[5].equals("0100111")){
            e="0";
        }else{
            e="0";
        }

        if(pecah[6].equals("0011001")||pecah[6].equals("1100110")||pecah[6].equals("0110011")){
            f = "1";
        }else
        if(pecah[6].equals("0010011")||pecah[6].equals("1101100")||pecah[6].equals("0011001")){
            f="2";
        }else
        if(pecah[6].equals("0111101")||pecah[6].equals("1000010")||pecah[6].equals("0100001")){
            f="3";
        }else
        if(pecah[6].equals("0100011")||pecah[6].equals("1011100")||pecah[6].equals("0011101")){
            f="4";
        }else
        if(pecah[6].equals("0110001")||pecah[6].equals("1001110")||pecah[6].equals("0111001")){
            f="5";
        }else
        if(pecah[6].equals("0101111")||pecah[6].equals("1010000")||pecah[6].equals("0000101")){
            f="6";
        }else
        if(pecah[6].equals("0111011")||pecah[6].equals("1000100")||pecah[6].equals("0010001")){
            f="7";
        }else
        if(pecah[6].equals("0110111")||pecah[6].equals("1001000")||pecah[6].equals("0001001")){
            f="8";
        }else
        if(pecah[6].equals("0001011")||pecah[6].equals("1110100")||pecah[6].equals("0010111")){
            f="9";
        }else
        if(pecah[6].equals("0001101")||pecah[6].equals("1110010")||pecah[6].equals("0100111")){
            f="0";
        }else{
            f="0";
        }

        if(pecah[8].equals("0011001")||pecah[8].equals("1100110")||pecah[8].equals("0110011")){
            g = "1";
        }else
        if(pecah[8].equals("0010011")||pecah[8].equals("1101100")||pecah[8].equals("0011001")){
            g="2";
        }else
        if(pecah[8].equals("0111101")||pecah[8].equals("1000010")||pecah[8].equals("0100001")){
            g="3";
        }else
        if(pecah[8].equals("0100011")||pecah[8].equals("1011100")||pecah[8].equals("0011101")){
            g="4";
        }else
        if(pecah[8].equals("0110001")||pecah[8].equals("1001110")||pecah[8].equals("0111001")){
            g="5";
        }else
        if(pecah[8].equals("0101111")||pecah[8].equals("1010000")||pecah[8].equals("0000101")){
            g="6";
        }else
        if(pecah[8].equals("0111011")||pecah[8].equals("1000100")||pecah[8].equals("0010001")){
            g="7";
        }else
        if(pecah[8].equals("0110111")||pecah[8].equals("1001000")||pecah[8].equals("0001001")){
            g="8";
        }else
        if(pecah[8].equals("0001011")||pecah[8].equals("1110100")||pecah[8].equals("0010111")){
            g="9";
        }else
        if(pecah[8].equals("0001101")||pecah[8].equals("1110010")||pecah[8].equals("0100111")){
            g="0";
        }else{
            g="0";
        }

        if(pecah[9].equals("0011001")||pecah[9].equals("1100110")||pecah[9].equals("0110011")){
            h = "1";
        }else
        if(pecah[9].equals("0010011")||pecah[9].equals("1101100")||pecah[9].equals("0011001")){
            h="2";
        }else
        if(pecah[9].equals("0111101")||pecah[9].equals("1000010")||pecah[9].equals("0100001")){
            h="3";
        }else
        if(pecah[9].equals("0100011")||pecah[9].equals("1011100")||pecah[9].equals("0011101")){
            h="4";
        }else
        if(pecah[9].equals("0110001")||pecah[9].equals("1001110")||pecah[9].equals("0111001")){
            h="5";
        }else
        if(pecah[9].equals("0101111")||pecah[9].equals("1010000")||pecah[9].equals("0000101")){
            h="6";
        }else
        if(pecah[9].equals("0111011")||pecah[9].equals("1000100")||pecah[9].equals("0010001")){
            h="7";
        }else
        if(pecah[9].equals("0110111")||pecah[9].equals("1001000")||pecah[9].equals("0001001")){
            h="8";
        }else
        if(pecah[9].equals("0001011")||pecah[9].equals("1110100")||pecah[9].equals("0010111")){
            h="9";
        }else
        if(pecah[9].equals("0001101")||pecah[9].equals("1110010")||pecah[9].equals("0100111")){
            h="0";
        }else{
            h="0";
        }

        if(pecah[10].equals("0011001")||pecah[10].equals("1100110")||pecah[10].equals("0110011")){
            i = "1";
        }else
        if(pecah[10].equals("0010011")||pecah[10].equals("1101100")||pecah[10].equals("0011001")){
            i="2";
        }else
        if(pecah[10].equals("0111101")||pecah[10].equals("1000010")||pecah[10].equals("0100001")){
            i="3";
        }else
        if(pecah[10].equals("0100011")||pecah[10].equals("1011100")||pecah[10].equals("0011101")){
            i="4";
        }else
        if(pecah[10].equals("0110001")||pecah[10].equals("1001110")||pecah[10].equals("0111001")){
            i="5";
        }else
        if(pecah[10].equals("0101111")||pecah[10].equals("1010000")||pecah[10].equals("0000101")){
            i="6";
        }else
        if(pecah[10].equals("0111011")||pecah[10].equals("1000100")||pecah[10].equals("0010001")){
            i="7";
        }else
        if(pecah[10].equals("0110111")||pecah[10].equals("1001000")||pecah[10].equals("0001001")){
            i="8";
        }else
        if(pecah[10].equals("0001011")||pecah[10].equals("1110100")||pecah[10].equals("0010111")){
            i="9";
        }else
        if(pecah[10].equals("0001101")||pecah[10].equals("1110010")||pecah[10].equals("0100111")){
            i="0";
        }else{
            i="0";
        }

        if(pecah[11].equals("0011001")||pecah[11].equals("1100110")||pecah[11].equals("0110011")){
            j = "1";
        }else
        if(pecah[11].equals("0010011")||pecah[11].equals("1101100")||pecah[11].equals("0011001")){
            j="2";
        }else
        if(pecah[11].equals("0111101")||pecah[11].equals("1000010")||pecah[11].equals("0100001")){
            j="3";
        }else
        if(pecah[11].equals("0100011")||pecah[11].equals("1011100")||pecah[11].equals("0011101")){
            j="4";
        }else
        if(pecah[11].equals("0110001")||pecah[11].equals("1001110")||pecah[11].equals("0111001")){
            j="5";
        }else
        if(pecah[11].equals("0101111")||pecah[11].equals("1010000")||pecah[11].equals("0000101")){
            j="6";
        }else
        if(pecah[11].equals("0111011")||pecah[11].equals("1000100")||pecah[11].equals("0010001")){
            j="7";
        }else
        if(pecah[11].equals("0110111")||pecah[11].equals("1001000")||pecah[11].equals("0001001")){
            j="8";
        }else
        if(pecah[11].equals("0001011")||pecah[11].equals("1110100")||pecah[11].equals("0010111")){
            j="9";
        }else
        if(pecah[11].equals("0001101")||pecah[11].equals("1110010")||pecah[11].equals("0100111")){
            j="0";
        }else{
            j="0";
        }

        if(pecah[12].equals("0011001")||pecah[12].equals("1100110")||pecah[12].equals("0110011")){
            k = "1";
        }else
        if(pecah[12].equals("0010011")||pecah[12].equals("1101100")||pecah[12].equals("0011001")){
            k="2";
        }else
        if(pecah[12].equals("0111101")||pecah[12].equals("1000010")||pecah[12].equals("0100001")){
            k="3";
        }else
        if(pecah[12].equals("0100011")||pecah[12].equals("1011100")||pecah[12].equals("0011101")){
            k="4";
        }else
        if(pecah[12].equals("0110001")||pecah[12].equals("1001110")||pecah[12].equals("0111001")){
            k="5";
        }else
        if(pecah[12].equals("0101111")||pecah[12].equals("1010000")||pecah[12].equals("0000101")){
            k="6";
        }else
        if(pecah[12].equals("0111011")||pecah[12].equals("1000100")||pecah[12].equals("0010001")){
            k="7";
        }else
        if(pecah[12].equals("0110111")||pecah[12].equals("1001000")||pecah[12].equals("0001001")){
            k="8";
        }else
        if(pecah[12].equals("0001011")||pecah[12].equals("1110100")||pecah[12].equals("0010111")){
            k="9";
        }else
        if(pecah[12].equals("0001101")||pecah[12].equals("1110010")||pecah[12].equals("0100111")){
            k="0";
        }else{
            k="0";
        }

        if(pecah[13].equals("0011001")||pecah[13].equals("1100110")||pecah[13].equals("0110011")){
            l = "1";
        }else
        if(pecah[13].equals("0010011")||pecah[13].equals("1101100")||pecah[13].equals("0011001")){
            l="2";
        }else
        if(pecah[13].equals("0111101")||pecah[13].equals("1000010")||pecah[13].equals("0100001")){
            l="3";
        }else
        if(pecah[13].equals("0100011")||pecah[13].equals("1011100")||pecah[13].equals("0011101")){
            l="4";
        }else
        if(pecah[13].equals("0110001")||pecah[13].equals("1001110")||pecah[13].equals("0111001")){
            l="5";
        }else
        if(pecah[13].equals("0101111")||pecah[13].equals("1010000")||pecah[13].equals("0000101")){
            l="6";
        }else
        if(pecah[13].equals("0111011")||pecah[13].equals("1000100")||pecah[13].equals("0010001")){
            l="7";
        }else
        if(pecah[13].equals("0110111")||pecah[13].equals("1001000")||pecah[13].equals("0001001")){
            l="8";
        }else
        if(pecah[13].equals("0001011")||pecah[13].equals("1110100")||pecah[13].equals("0010111")){
            l="9";
        }else
        if(pecah[13].equals("0001101")||pecah[13].equals("1110010")||pecah[13].equals("0100111")){
            l="0";
        }else{
            l="0";
        }


        if(a.equals("7")&&b.equals("8")||a.equals("7")&&b.equals("7")||a.equals("7")&&b.equals("9")){

            has="Maaf Bukan Barcode Produk";
        }else
        if(a.equals("9")&&b.equals("9")||a.equals("8")&&b.equals("0")||a.equals("8")&&b.equals("8")
                ||a.equals("8")&&b.equals("5")||a.equals("9")&&b.equals("0")||a.equals("9")&&b.equals("3")
                ||a.equals("6")&&b.equals("9")){
            t="8";
            has=t+a+b+c+d+e+f+g+h+i+j+k+l;
        }else
        if(a.equals("6")){
            t="7";
            has=t+a+b+c+d+e+f+g+h+i+j+k+l;
        }else if(a.equals("5")&&b.equals("5")||a.equals("2")||a.equals("4")){
            t="9";
            has=t+a+b+c+d+e+f+g+h+i+j+k+l;
        }
        else {
            t="";
            has=t+a+b+c+d+e+f+g+h+i+j+k+l;
        }

        return has;
    }

    public Bitmap replaceColor(Bitmap src) {
        if(src == null) {
            return null;
        }
        // Source image size
        //src= getResizedBitmap(src, 300, 100);
        src=replaceColortb(src);
        //src=createContrast(src,50);
        int width = src.getWidth();
        int height = src.getHeight();
        int[] pixels = new int[width * height];
        //get pixels
        src.getPixels(pixels, 0, width, 0, 0, width, height);

        for(int x = 0; x < pixels.length; ++x) {
            pixels[x] = (pixels[x] == Color.BLACK) ? pixels[x] : Color.TRANSPARENT;
        }
        // create result bitmap output
        Bitmap result = Bitmap.createBitmap(width, height, src.getConfig());
        //set pixels
        result.setPixels(pixels, 0, width, 0, 0, width, height);

        return result;
    }
    public Bitmap replaceColortw(Bitmap src) {
        if(src == null) {
            return null;
        }
        // Source image size
        int width = src.getWidth();
        int height = src.getHeight();
        int[] pixels = new int[width * height];
        //get pixels
        src.getPixels(pixels, 0, width, 0, 0, width, height);

        for(int x = 0; x < pixels.length; ++x) {
            pixels[x] = (pixels[x] == Color.TRANSPARENT) ? Color.WHITE : pixels[x];
        }
        // create result bitmap output
        Bitmap result = Bitmap.createBitmap(width, height, src.getConfig());
        //set pixels
        result.setPixels(pixels, 0, width, 0, 0, width, height);

        return result;
    }public Bitmap replaceColortb(Bitmap src) {
        if(src == null) {
            return null;
        }
        // Source image size
        src = toBinner(src);
        //src=createContrast(src,85);

        int width = src.getWidth();
        int height = src.getHeight();
        int[] pixels = new int[width * height];
        //get pixels
        src.getPixels(pixels, 0, width, 0, 0, width, height);

        for(int x = 0; x < pixels.length; ++x) {
            pixels[x] = (pixels[x] == Color.BLACK) ? Color.BLACK : Color.WHITE ;
        }
        // create result bitmap output
        Bitmap result = Bitmap.createBitmap(width, height, src.getConfig());
        //set pixels
        result.setPixels(pixels, 0, width, 0, 0, width, height);

        return result;
    }
    public static Bitmap createTrimmedBitmap(Bitmap bmp) {

        int imgHeight = bmp.getHeight();
        int imgWidth  = bmp.getWidth();
        int smallX=0,largeX=imgWidth,smallY=0,largeY=imgHeight;
        int left=imgWidth,right=imgWidth,top=imgHeight,bottom=imgHeight;
        for(int i=0;i<imgWidth;i++)
        {
            for(int j=0;j<imgHeight;j++)
            {
                if(bmp.getPixel(i, j) != Color.TRANSPARENT){
                    if((i-smallX)<left){
                        left=(i-smallX);
                    }
                    if((largeX-i)<right)
                    {
                        right=(largeX-i);
                    }
                    if((j-smallY)<top)
                    {
                        top=(j-smallY);
                    }
                    if((largeY-j)<bottom)
                    {
                        bottom=(largeY-j);
                    }
                }
            }
        }
        Log.d("size", "left:" + left + " right:" + right + " top:" + top + " bottom:" + bottom);
        bmp=Bitmap.createBitmap(bmp,left,top,imgWidth-left-right, imgHeight-top-bottom);

        return bmp;
    }

}
