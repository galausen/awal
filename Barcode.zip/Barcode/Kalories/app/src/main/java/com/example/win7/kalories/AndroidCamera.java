package com.example.win7.kalories;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AndroidCamera extends Activity implements SurfaceHolder.Callback{

	Camera camera;
	SurfaceView surfaceView;
	SurfaceHolder surfaceHolder;
	boolean previewing = false;
	LayoutInflater controlInflater = null;
	ImageView imshow;
	TextView txt;
	String barcode,hsl,nama,lemak,protein,karbo,barcf,namf,lemf,prof,karf,jum,jumf,jenf,katf,akses;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);




        getWindow().setFormat(PixelFormat.UNKNOWN);
        surfaceView = (SurfaceView)findViewById(R.id.camerapreview);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        
        controlInflater = LayoutInflater.from(getBaseContext());
        View viewControl = controlInflater.inflate(R.layout.control, null);
        LayoutParams layoutParamsControl 
        	= new LayoutParams(LayoutParams.FILL_PARENT, 
        	LayoutParams.FILL_PARENT);
        this.addContentView(viewControl, layoutParamsControl);


		imshow = (ImageView) findViewById(R.id.imageView2);
		txt = (TextView) findViewById(R.id.textView6);
        Button buttonTakePicture = (Button)findViewById(R.id.takepicture);
        buttonTakePicture.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				onPick();

				// TODO Auto-generated method stub
				//camera.takePicture(myShutterCallback,
						//myPictureCallback_RAW, myPictureCallback_JPG);
			}});
    }
	public void onPick(){
		//configure();

		camera.autoFocus(new Camera.AutoFocusCallback() {
			@Override
			public void onAutoFocus(boolean success, Camera camera) {
				if (success) {

						camera.takePicture(myShutterCallback,
								myPictureCallback_RAW, myPictureCallback_JPG);
						//surfaceView.setVisibility(View.GONE);


				}
			}
		});

	}
    
    ShutterCallback myShutterCallback = new ShutterCallback(){

		@Override
		public void onShutter() {
			// TODO Auto-generated method stub
			
		}};
		
	PictureCallback myPictureCallback_RAW = new PictureCallback(){

		@Override
		public void onPictureTaken(byte[] arg0, Camera arg1) {
			// TODO Auto-generated method stub
			
		}};

	PictureCallback myPictureCallback_JPG = new PictureCallback() {

		@Override
		public void onPictureTaken(byte[] arg0, Camera arg1) {
			BitmapFactory.Options opt = new BitmapFactory.Options();
			opt.inMutable = true;
			Bitmap bitmapPicture
					= BitmapFactory.decodeByteArray(arg0, 0, arg0.length, opt);
			Bitmap correctBmp = Bitmap.createBitmap(bitmapPicture, 0, 0, bitmapPicture.getWidth(), bitmapPicture.getHeight(), null, true);
			//Bitmap res = Bitmap.createScaledBitmap(correctBmp,600,500,true);
			Bitmap crop = scaleCenterCrop(correctBmp, 600, 50);
			Bitmap rot = roTate(crop);
			ByteArrayOutputStream stream =new ByteArrayOutputStream();
			rot.compress(Bitmap.CompressFormat.PNG,100,stream);
			byte[] byteArray = stream.toByteArray();
			Intent ak= new Intent(AndroidCamera.this, Preproses.class);
			ak.putExtra("image",byteArray);
			startActivity(ak);
			finish();
		}
	};


	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		if(previewing){
			camera.stopPreview();
			previewing = false;
		}
		
		if (camera != null){
			try {
				Camera.Parameters params = camera.getParameters();
//*EDIT*//params.setFocusMode("continuous-picture");
//It is better to use defined constraints as opposed to String, thanks to AbdelHady

				List<Integer> formats = params.getSupportedPictureFormats();
				if (formats.contains(PixelFormat.RGB_565))
					params.setPictureFormat(PixelFormat.RGB_565);
				else
					params.setPictureFormat(PixelFormat.JPEG);


				// Choose the biggest picture size supported by the hardware
				List<Camera.Size> sizes = params.getSupportedPictureSizes();
				List<Camera.Size> sizeList = params.getSupportedPictureSizes();
				int chosenSize = getPictureSizeIndexForHeight(sizeList, 1200);
				params.setPictureSize(sizeList.get(chosenSize).width, sizeList.get(chosenSize).height);


				//params.setPictureSize(Constants.IMAGE_WIDTH, SyncStateContract.Constants.IMAGE_HEIGHT);
				boolean hasFlash = getApplicationContext().getPackageManager()
						.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

				/*if (!hasFlash) {
					// device doesn't support flash
					// Show alert message and close the application
					Toast.makeText(AndroidCamera.this, "Flash Kamera Tidak didukung", Toast.LENGTH_LONG).show();
				}else {
				List<String> flashModes = params.getSupportedFlashModes();
				if (flashModes.size() > 0)
					params.setFlashMode(Camera.Parameters.FLASH_MODE_AUTO);
				}*/
				params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
				camera.setParameters(params);
				//getCon();
				//configure();
				camera.setPreviewDisplay(surfaceHolder);
				camera.setDisplayOrientation(90);
				camera.startPreview();
				previewing = true;
				/*camera.autoFocus(new Camera.AutoFocusCallback() {
					@Override
					public void onAutoFocus(boolean success, Camera camera) {
						if (success) {
							camera.takePicture(myShutterCallback,
									myPictureCallback_RAW, myPictureCallback_JPG);
						}
					}
				});*/
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		camera = Camera.open();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		camera.stopPreview();
		camera.release();
		camera = null;
		previewing = false;
	}
	public Bitmap scaleCenterCrop(Bitmap source, int newHeight, int newWidth) {
		int sourceWidth = source.getWidth();
		int sourceHeight = source.getHeight();


		float xScale = (float) newWidth / sourceWidth;
		float yScale = (float) newHeight / sourceHeight;
		float scale = Math.max(xScale, yScale);


		float scaledWidth = scale * sourceWidth;
		float scaledHeight = scale * sourceHeight;


		float left = (newWidth - scaledWidth) / 2;
		float top = (newHeight - scaledHeight) / 2;
		Toast.makeText(this, "left"+left+"toop"+top+"scale:"+scale,Toast.LENGTH_LONG).show();

		RectF targetRect = new RectF(left, top-650, left + scaledWidth, top + scaledHeight+650);


		Bitmap dest = Bitmap.createBitmap(newWidth, newHeight, source.getConfig());
		Canvas canvas = new Canvas(dest);
		canvas.drawBitmap(source, null, targetRect, null);

		return dest;
	}
	public Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth)
	{
		int width = bm.getWidth();
		int height = bm.getHeight();
		float scaleWidth = ((float) newWidth) / width;
		float scaleHeight = ((float) newHeight) / height;

		Matrix matrix = new Matrix();

		matrix.postScale(scaleWidth, scaleHeight);

		Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);
		return resizedBitmap;
	}
	public void configure() {
		Camera.Parameters params = camera.getParameters();

		// Configure image format. RGB_565 is the most common format.
		List<Integer> formats = params.getSupportedPictureFormats();
		if (formats.contains(PixelFormat.RGB_565))
			params.setPictureFormat(PixelFormat.RGB_565);
		else
			params.setPictureFormat(PixelFormat.JPEG);


		// Choose the biggest picture size supported by the hardware
        List<Camera.Size> sizes = params.getSupportedPictureSizes();
		List<Camera.Size> sizeList = params.getSupportedPictureSizes();
		int chosenSize = getPictureSizeIndexForHeight(sizeList, 1200);
		params.setPictureSize(sizeList.get(chosenSize).width, sizeList.get(chosenSize).height);


		//params.setPictureSize(Constants.IMAGE_WIDTH, SyncStateContract.Constants.IMAGE_HEIGHT);
		boolean hasFlash = getApplicationContext().getPackageManager()
				.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

			if (!hasFlash) {
				// device doesn't support flash
				// Show alert message and close the application
				Toast.makeText(AndroidCamera.this, "Flash Kamera Tidak didukung", Toast.LENGTH_LONG).show();
			}else {}
			List<String> flashModes = params.getSupportedFlashModes();
			if (flashModes.size() > 0) {
				params.setFlashMode(Camera.Parameters.FLASH_MODE_AUTO);
			}
		// Action mode take pictures of fast moving objects
		/*List<String> sceneModes = params.getSupportedSceneModes();
		if (sceneModes.contains(Camera.Parameters.SCENE_MODE_ACTION))
			params.setSceneMode(Camera.Parameters.SCENE_MODE_ACTION);
		else
			params.setSceneMode(Camera.Parameters.SCENE_MODE_AUTO);*/

		// if you choose FOCUS_MODE_AUTO remember to call autoFocus() on
		// the Camera object before taking a picture
		params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
		camera.setParameters(params);
	}
	public static int getPictureSizeIndexForHeight(List<Camera.Size> sizeList, int height) {
		int chosenHeight = -1;
		for(int i=0; i<sizeList.size(); i++) {
			if(sizeList.get(i).height < height) {
				chosenHeight = i-1;
				if(chosenHeight==-1)
					chosenHeight = 0;
				break;
			}
		}
		return chosenHeight;
	}

	public Bitmap roTate(Bitmap bitmap){
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();
		Matrix matrix = new Matrix();

		matrix.postRotate(90);

		Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);

		Bitmap rotatedBitmap = Bitmap.createBitmap(scaledBitmap , 0, 0, scaledBitmap .getWidth(), scaledBitmap .getHeight(), matrix, true);
		return rotatedBitmap;
	}
	public void onBackPressed() {
		super.onBackPressed();
		Intent m = new Intent(this, Preproses.class);
		m.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(m);
		finish();
	}
	public void onPro(String bcde){
		final String barcode;

	}

}