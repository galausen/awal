package com.example.win7.kalories;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Prince Karen 1 on 8/5/2016.
 */
public class Preproses extends AppCompatActivity {
    ImageView ivAwal,ivHasil,ivCrop;
    Button getImage,proSes,pro,num,cam,sb,tostr;
    TextView pisel,txvw;
    private static final int PICK_IMAGE_REQUEST = 1;
    Bitmap bitmap,tmpbmp,bmpdefault;
    Pcd pcd = new Pcd();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre);
        ivAwal = (ImageView) findViewById(R.id.img_awal);
        ivHasil = (ImageView) findViewById(R.id.img_gray);
        ivCrop = (ImageView) findViewById(R.id.imgcrop);
        getImage = (Button) findViewById(R.id.button1);
        proSes = (Button) findViewById(R.id.button2);
        pro = (Button) findViewById(R.id.button3);
        num = (Button) findViewById(R.id.button4);
        pisel = (TextView) findViewById(R.id.textView);
        txvw = (TextView) findViewById(R.id.textView1);
        sb= (Button) findViewById(R.id.button5);
        final ImageView ivSet= (ImageView) findViewById(R.id.img1);
        final ImageView ivCp = (ImageView) findViewById(R.id.img2);
        tostr= (Button) findViewById(R.id.button6);
        cam = (Button) findViewById(R.id.button0);
        pro.setEnabled(false);
        num.setEnabled(false);
        sb.setEnabled(false);
        tostr.setEnabled(false);
        byte[] byteArray = getIntent().getByteArrayExtra("image");
        if (byteArray!=null) {
            Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
            ivAwal.setImageBitmap(bmp);
        }
        cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =null;
                i = new Intent(Preproses.this, AndroidCamera.class);
                startActivity(i);
                finish();

            }
        });

        getImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent chooseImage=new Intent();
                chooseImage.setType("image/*");
                chooseImage.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(chooseImage, "Select Picture"),PICK_IMAGE_REQUEST);

            }
        });
        proSes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    BitmapDrawable bitmapDrawable=(BitmapDrawable)ivAwal.getDrawable();
                    bitmap=bitmapDrawable.getBitmap();
                    Bitmap scalCrop=pcd.scaleCenterCrop(bitmap, 50, bitmap.getWidth());
                    ivHasil.setImageBitmap(scalCrop);
                    Toast.makeText(Preproses.this, "Successfully", Toast.LENGTH_SHORT).show();
                    pro.setEnabled(true);
                }catch (Exception e){

                }
            }
        });
        pro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    BitmapDrawable bitmapDrawable=(BitmapDrawable)ivHasil.getDrawable();
                    bitmap=bitmapDrawable.getBitmap();
                    Bitmap bin=pcd.toBinner(bitmap);
                    ivCrop.setImageBitmap(bin);
                    Toast.makeText(Preproses.this, "Crop Successfully", Toast.LENGTH_SHORT).show();
                    num.setEnabled(true);
                }catch (Exception e){

                }
            }
        });
        num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    BitmapDrawable bitmapDrawable=(BitmapDrawable)ivCrop.getDrawable();
                    bitmap=bitmapDrawable.getBitmap();
                    Bitmap RcOl= pcd.replaceColor(bitmap);
                    Bitmap rTim=pcd.createTrimmedBitmap(RcOl);
                    Bitmap tw = pcd.replaceColortw(rTim);
                    ivSet.setImageBitmap(tw);
                    Toast.makeText(Preproses.this, "Successfully", Toast.LENGTH_SHORT).show();
                    sb.setEnabled(true);
                }catch (Exception e){

                }
            }
        });
        sb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    BitmapDrawable bitmapDrawable=(BitmapDrawable)ivSet.getDrawable();
                    bitmap=bitmapDrawable.getBitmap();
                    Bitmap cr = pcd.scaleCenterCrop(bitmap,1,95);
                    ivCp.setImageBitmap(cr);
                    tostr.setEnabled(true);
                }catch (Exception e){


                }
            }
        });
        tostr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    BitmapDrawable bitmapDrawable=(BitmapDrawable)ivCp.getDrawable();
                    bitmap=bitmapDrawable.getBitmap();
                    pisel.setText(pcd.toNumber(bitmap));
                    String str = pisel.getText().toString();
                    String[] pch = str.split(",");
                    txvw.setText(pcd.iniSial(pch));
                    pro.setEnabled(false);
                    num.setEnabled(false);
                    sb.setEnabled(false);
                    tostr.setEnabled(false);
                }catch (Exception e){


                }
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try{
            Bitmap bp=(Bitmap)data.getExtras().get("data");
            ivAwal.setImageBitmap(bp);

            // Membuat Default
            bmpdefault=bp;
        }catch (Exception e){

        }
        // Ini Untuk Choose Gambar
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data !=null && data.getData() != null){
            Uri uri=data.getData();
            try{
                bitmap= MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                ivAwal.setImageBitmap(bitmap);

                // Membuat Defualt
                bmpdefault=bitmap;
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    public void onBackPressed() {
        super.onBackPressed();
        Intent m = new Intent(this, MainActivity.class);
        m.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(m);
        finish();
    }

}
